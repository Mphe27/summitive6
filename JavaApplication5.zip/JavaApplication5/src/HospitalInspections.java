import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class HospitalInspections extends JFrame {

    // Declare the form controls
    private JTextField txtHospitalName;
    private JTextField txtHospitalLocation;
    private JComboBox<String> cmbYears;
    private DefaultListModel<String> listModel;
    private JList<String> lstHospitals;

    private JButton btnSave;
    private JButton btnPrint;
    private JButton btnClear;

    // Create an array to store a maximum of 5 records
    private HospitalInspection[] inspections =
            new HospitalInspection[5];

    private int count = 0;

    // Constructor
    public HospitalInspections() {

        setTitle("Hospital Inspections");
        setSize(500, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create the main panel
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(
                15, 15, 15, 15));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Hospital name
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Hospital Name:"), gbc);

        txtHospitalName = new JTextField(20);
        gbc.gridx = 1;
        panel.add(txtHospitalName, gbc);

        // Hospital location
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Hospital Location:"), gbc);

        txtHospitalLocation = new JTextField(20);
        gbc.gridx = 1;
        panel.add(txtHospitalLocation, gbc);

        // Years since inspection
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Years since inspection:"), gbc);

        cmbYears = new JComboBox<>(new String[]{
            "1 Year",
            "2 Years",
            "3 Years",
            "4 Years",
            "5 Years"
        });

        gbc.gridx = 1;
        panel.add(cmbYears, gbc);

        // Save button
        btnSave = new JButton("SAVE");
        gbc.gridx = 1;
        gbc.gridy = 3;
        panel.add(btnSave, gbc);

        // List box
        listModel = new DefaultListModel<>();
        lstHospitals = new JList<>(listModel);

        JScrollPane scrollPane = new JScrollPane(lstHospitals);
        scrollPane.setPreferredSize(new Dimension(350, 150));

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        panel.add(scrollPane, gbc);

        // Print and Clear buttons
        JPanel buttonPanel = new JPanel();

        btnPrint = new JButton("PRINT");
        btnClear = new JButton("CLEAR");

        buttonPanel.add(btnPrint);
        buttonPanel.add(btnClear);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(buttonPanel, gbc);

        add(panel);

        // SAVE button event
        btnSave.addActionListener(e -> saveInspection());

        // PRINT button event
        btnPrint.addActionListener(e -> printInspections());

        // CLEAR button event
        btnClear.addActionListener(e -> clearControls());
    }

    // Method to save hospital inspection details
    private void saveInspection() {

        String name = txtHospitalName.getText().trim();
        String location = txtHospitalLocation.getText().trim();
        String years = (String) cmbYears.getSelectedItem();

        if (name.isEmpty() || location.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter the hospital name and location.");
            return;
        }

        if (count >= inspections.length) {
            JOptionPane.showMessageDialog(this,
                    "Maximum of five hospital records reached!");
            return;
        }

        // Store details in the array
        inspections[count] = new HospitalInspection(
                name, location, years);

        count++;

        JOptionPane.showMessageDialog(this,
                "Hospital inspection details saved successfully!");

        clearControls();
    }

    // Method to print records into the list box
    private void printInspections() {

        listModel.clear();

        if (count == 0) {
            JOptionPane.showMessageDialog(this,
                    "No hospital records have been saved.");
            return;
        }

        for (int i = 0; i < count; i++) {

            HospitalInspection h = inspections[i];

            String details = "Hospital: " + h.name
                    + " | Location: " + h.location
                    + " | Years: " + h.years;

            listModel.addElement(details);
        }
    }

    // Method to clear the form controls
    private void clearControls() {

        txtHospitalName.setText("");
        txtHospitalLocation.setText("");
        cmbYears.setSelectedIndex(0);

        txtHospitalName.requestFocus();
    }

    // Hospital inspection class
    static class HospitalInspection {

        String name;
        String location;
        String years;

        HospitalInspection(String name,
                           String location,
                           String years) {

            this.name = name;
            this.location = location;
            this.years = years;
        }
    }

    // Main method
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new HospitalInspections().setVisible(true);
        });
    }
}